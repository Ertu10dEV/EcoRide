// Simple placeholder pour plus tard
document.querySelector('.search-form').addEventListener('submit', e => {
  e.preventDefault();
  alert('La recherche de trajets arrivera bientôt !');
});
